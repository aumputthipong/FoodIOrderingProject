<template>
  <div>
    <section class="hero">
      <div class="hero-body ml-5">
        <p class="title">Create a New Blog</p>
      </div>
    </section>
    <section class="container">
        <div class="content">
          <div class="field">
            <label class="label">Title</label>
            <input class="input" type="text" name="shopname" placeholder="Shop name" v-model="shopname">
            <p class="help is-danger">*Required</p>
          </div>
          <div class="field">
            <label class="label">Content</label>
            <div class="control">
              <textarea class="textarea" placeholder="รายละเอียดร้าน" name="describe" v-model="describe"></textarea>
              <p class="help is-danger">*Required</p>
            </div>
          </div>
          <div class="file">
            <label class="file-label">
              <input class="file-input" type="file" id="file" ref="file" name="shop_image" @change="handleFileUpload()">
              <span class="file-cta">
                <span class="file-icon">
                  <i class="fas fa-upload"></i>
                </span>
                <span class="file-label">
                  Choose an image…
                </span>
              </span>
            </label>
          </div>
          <div class="field is-grouped mt-3">
            <div class="control">
              <input type="button" class="button is-link" value="submit" @click="submit()">
            </div>
            <div class="control">
              <router-link to="/">
              <button class="button is-link is-light">Back to home</button>
              </router-link>
            </div>
          </div>
        </div>
    </section>
  </div>
</template>

<script>
import axios from "@/plugins/axios";

export default {
  data() {
    return {
      shopname: "",
      describe: "",
      file: null,
    };
  },
  methods: {
    handleFileUpload() {
      this.file = this.$refs.file.files[0];
    },
    submit() {
      var formData = new FormData();
      formData.append("shop_image", this.file);
      formData.append("shopname", this.shopname);
      formData.append("describe", this.describe);
      
      axios
        .post("http://localhost:3000/createshop", formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then((response) => {
          console.log(response)
          this.$router.push({ path: "/" }); // Success! -> redirect to home page
        })
        .catch((error) => {
          console.log(error.message);
        });
    },
  },
};
</script>

<style scoped>
</style>