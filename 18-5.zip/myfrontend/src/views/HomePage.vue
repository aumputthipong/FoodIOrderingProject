<template>
  <div class="container is-widescreen">
    <section class="section" id="app">
      <div class="content">
        <div class="columns is-multiline">
          <div class="column is-4" v-for="blog in blogs" :key="blog.id">
            <div class="card">
              <div class="card-image pt-5">
                <img
                  style="height: 120px"
                  :src="imagePath(blog.picture)"
                  alt="Placeholder image"
                />
              </div>
              <div class="card-content">
                <div class="title">{{ blog.name }}</div>
                <div class="content" style="height: 200px">
                  {{ shortContent(blog.description) }}
                </div>
              </div>
              <footer class="card-footer">
                <router-link
                  class="card-footer-item"
                  :to="`/shop/detail/${blog.id}`"
                  >Read more...</router-link
                >
                <!-- <a class="card-footer-item" @click="addLike(blog.id)">
                  <span class="icon-text">
                    <span class="icon">
                      <i class="far fa-heart"></i>
                    </span>
                    <span>Like ({{blog.like}})</span>
                  </span>
                </a> -->
                <!-- <a
                  class="card-footer-item"
                  @click="$router.push({name:'update-blog',params:{id:blog.id}})"
                >
                  <span class="icon-text">
                    <span>Edit</span>
                  </span>
                </a> -->
              </footer>
            </div>
          </div>
        </div>
        <!-- <form method="GET" action="/">
            <div class="columns">
              <div class="column is-2">
                <router-link to="/create/createshop">
                  <button class="button is-link is-light">Create Shop</button>
                </router-link>
              </div>
            </div>
          </form> -->
      </div>
    </section>
  </div>
</template>

<script>
import axios from "@/plugins/axios";

export default {
  name: "HomePage",
  data() {
    return {
      blogs: [],
    };
  },
  mounted() {
    // re
    // setInterval(() => {
    //   location.reload();
    // }, 10000);

    axios
      .get("http://localhost:3000/")
      .then((response) => {
        this.blogs = response.data;
        console.log(this.blogs);
      })
      .catch((err) => {
        console.log(err);
      });
  },
  methods: {
    imagePath(file_path) {
      if (file_path) {
        return "http://localhost:3000/" + file_path;
      } else {
        return "https://bulma.io/images/placeholders/640x360.png";
      }
    },
    shortContent(content) {
      if (content.length > 200) {
        return content.substring(0, 197) + "...";
      }
      return content;
    },
  },
};
</script>

<style scoped>
</style>