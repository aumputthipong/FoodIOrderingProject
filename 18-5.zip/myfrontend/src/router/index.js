import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
    {
        path: '/',
        name: 'Home',
        meta: { guess: true },
        component: () => import('../views/HomePage') // set home as path '/'
    },
    {
        path: '/shop/detail/:id',
        name: 'ShopDetail',
        meta: { guess: true },
        component: () => import('../views/detail/ShopDetail.vue')
    },
    {
        path: '/create/createshop',
        name: 'createshop',
        meta: { login: true },
        component: () => import('../views/create/CreateShop.vue')
    },
    {
        path: '/createproduct/:shopid',
        name: 'createproduct',
        meta: { login: true },
        component: () => import('../views/create/CreateProduct.vue')
    },
    {
        path: '/user/signup',
        name: 'signup',
        meta: { guess: true },
        component: () => import('../views/SignUp.vue')
    },
    {
        path: "/user/login",
        name: 'login',
        meta: { guess: true },
        component: () => import("../views/LoginComponent.vue")
    },

];

const router = new VueRouter({ routes });

router.beforeEach((to, from, next) => {
    const isLoggedIn = !!localStorage.getItem('token')

    if (to.meta.login && !isLoggedIn) {
        alert('Please login first!');
        next({ path: '/user/login' });
    }

    next();
});

export default router
