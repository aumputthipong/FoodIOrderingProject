const express = require("express");
const pool = require("../config");
const Joi = require('joi')
const bcrypt = require('bcrypt')
const { isLoggedIn } = require('../middlewares')

router = express.Router();

router.post("/updatecart/:shopId", isLoggedIn, async function (req, res, next) {
    const cart = req.body.cart;

    const conn = await pool.getConnection()
    await conn.beginTransaction()

    try {
        for (let i = 0; i < cart.length; i++) {
            const data = cart[i];

            // checkว่ามีของอยู่แล้วไหม
            const [rows1, fields1] = await conn.query(
                "SELECT * From cart_items JOIN carts ON(cart_items.cart_id = carts.id) where cart_items.product_id = ?", [data.id]
            )
            // ตะกร้าใบไหน
            const [rowsselectcart, fields2] = await conn.query(
                "SELECT * FROM carts JOIN cart_items ON (carts.id = cart_items.cart_id) where user_id = ? ", [req.user.id]
            )
            // console.log(rowsselectcart[0].id)
            console.log(data.product_id)
            console.log({ สนใจ: data })
            console.log({ สนใจ2: rowsselectcart[0].cart_id })
            if (rows1.length === 0) {
                await conn.query(
                    "insert INTO cart_items (cart_id , product_id, quantity) VALUES(?, ?, ?)", [rowsselectcart[0].cart_id, data.id, data.quantity]
                )
            }
            else {
                await conn.query(
                    "UPDATE cart_items SET quantity = ? WHERE product_id = ? AND cart_id = ?", [data.quantity, data.id, data.cart_id]
                )
            }
        }
        //   res.status(500).json(rowsselectcart)
        await conn.commit()
        res.redirect('/')
    } catch (err) {
        await conn.rollback();
        next(err);
    } finally {
        console.log('finally')
        conn.release();
    }
});

router.delete("/delete/:productId", isLoggedIn, async function (req, res, next) {


    const conn = await pool.getConnection()
    await conn.beginTransaction()

    try {
        const [rowsselectcart, fields2] = await conn.query(
            "SELECT * FROM carts JOIN cart_items ON (carts.id = cart_items.cart_id) where user_id = ? ", [req.user.id]
        )
        const [rows1, fields1] = await pool.query(
            "DELETE FROM cart_items WHERE product_id = ? AND cart_id = ?",
            [req.params.productId, rowsselectcart[0].cart_id]
        );
        res.json("success");
        await conn.commit()
        res.redirect('/')
    } catch (err) {
        await conn.rollback();
        next(err);
    } finally {
        console.log('finally')
        conn.release();
    }
}
);


router.get("/shop/cart/:shopId", isLoggedIn, async function (req, res, next) {
    const promise1 = pool.query(`SELECT * FROM carts JOIN cart_items 
    ON (carts.id = cart_items.cart_id) JOIN products ON(cart_items.product_id = products.id)
    WHERE user_id = ? and shop_id= ?;`, [
        req.user.id, req.params.shopId,
    ]);

    // Use Promise.all() to make sure that all queries are successful
    Promise.all([promise1,])
        .then((results) => {
            const [cart, blogFields] = results[0];
            res.json({
                cart: cart,
                error: null,
            });

        })
        .catch((err) => {
            return res.status(500).json(err);
        });
});

exports.router = router