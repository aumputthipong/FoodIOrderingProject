const express = require("express");
const path = require("path")
const pool = require("../config");
const multer = require('multer');
const { isLoggedIn } = require('../middlewares')

router = express.Router();

var storage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, './static/uploads') // path to save file
    },
    filename: function (req, file, callback) {
        // set file name
        callback(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
    }
})
const upload = multer({ storage: storage })

router.get("/shop/detail/:id", async function (req, res, next) {
    const promise1 = pool.query("SELECT * FROM shops WHERE id=?", [
        req.params.id,
    ]);
    const promise2 = pool.query("SELECT * FROM products WHERE shop_id=?", [req.params.id]);

    // const promise3 = pool.query("SELECT * FROM carts JOIN cart_items ON carts.id = cart_id JOIN products ON cart_items.product_id = products.id WHERE shop_id=?", [req.params.id]);


    // Use Promise.all() to make sure that all queries are successful
    Promise.all([promise1, promise2])
        .then((results) => {
            const [shops, blogFields] = results[0];
            const [products, productFields] = results[1];
            res.json({
                shop: shops[0],
                products: products,
                error: null,
            });

        })
        .catch((err) => {
            return res.status(500).json(err);
        });
});




router.post("/createproduct/:shopid",isLoggedIn, upload.single('product_image'), async function (req, res, next) {


    const pro_name = req.body.pro_name
    const pro_description = req.body.pro_description
    const pro_price = req.body.pro_price

    const file = req.file;
    if (!file) {
        const error = new Error("Please upload a file");
        error.httpStatusCode = 400;
        return next(error);
    }

    const conn = await pool.getConnection();
    await conn.beginTransaction();
    try {
        const [rows1, field1] = await conn.query(
            "INSERT INTO `products` (`name`, `description`, `picture`,`price`,`status`,`shop_id`) VALUES (?,?,?,?,'not-available',?)",
            [pro_name, pro_description, file.path.substr(6), pro_price, req.params.shopid],
        )

        await conn.commit();
        res.redirect('/')
    } catch (err) {

        await conn.rollback();
        next(err)
    } finally {
        conn.release();
    }
});


router.get("/createproduct/:id",isLoggedIn, async function (req, res, next) {
    const promise1 = pool.query("SELECT * FROM shops WHERE id=?", [
        req.params.id,
    ]);


    // Use Promise.all() to make sure that all queries are successful
    Promise.all([promise1,])
        .then((results) => {
            const [shops, shopFields] = results[0];
            
            res.json({
                shop: shops[0],
                error: null,
            });
            

        })
        .catch((err) => {
            return res.status(500).json(err);
        });
});


exports.router = router;
