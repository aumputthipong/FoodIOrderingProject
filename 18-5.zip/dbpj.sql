-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: webproproject
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cart_items`
--

DROP TABLE IF EXISTS `cart_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_items` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `cart_id` varchar(45) DEFAULT NULL,
  `product_id` varchar(45) DEFAULT NULL,
  `quantity` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_items`
--

LOCK TABLES `cart_items` WRITE;
/*!40000 ALTER TABLE `cart_items` DISABLE KEYS */;
INSERT INTO `cart_items` VALUES (10,NULL,'10','1'),(11,NULL,'10','1'),(12,NULL,'10','1'),(13,NULL,'10','1'),(14,NULL,'10','1'),(15,NULL,'10','1'),(16,NULL,'10','1'),(17,NULL,'10','1'),(22,'1','12','12'),(29,'1',NULL,'1'),(30,'1',NULL,'1'),(31,'1',NULL,'1'),(32,'1',NULL,'1'),(33,'1',NULL,'2'),(48,'1','4','1'),(49,'1','8','3'),(50,'1','2','3'),(51,'1','9','4'),(52,'1','5','1');
/*!40000 ALTER TABLE `cart_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carts`
--

DROP TABLE IF EXISTS `carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `carts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carts`
--

LOCK TABLES `carts` WRITE;
/*!40000 ALTER TABLE `carts` DISABLE KEYS */;
INSERT INTO `carts` VALUES (1,'1'),(2,'2'),(3,'3'),(4,'4');
/*!40000 ALTER TABLE `carts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  `picture` varchar(45) DEFAULT NULL,
  `price` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `shop_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'เตี๋ยวหมู','หร่อยๆ','\\uploads\\product_image-1684223446335.png','100','not-available','1'),(2,'เตี๋ยวไก่','wow','\\uploads\\product_image-1684230075449.jpg','50','not-available','1'),(3,'d','d','\\uploads\\product_image-1684230186211.jpg','1','not-available','2'),(4,'เตี๋ยวเป็ด','ggs','\\uploads\\product_image-1684230263409.jpg','45','not-available','1'),(5,'เตี๋ยวเป็ด','ggs','\\uploads\\product_image-1684230270541.jpg','45','not-available','1'),(6,'1','3','\\uploads\\product_image-1684230289028.jpg','2','not-available','2'),(7,NULL,NULL,'\\uploads\\product_image-1684230304401.png',NULL,'not-available','1'),(8,'1','3','\\uploads\\product_image-1684230384983.jpg','2','not-available','2'),(9,NULL,NULL,'\\uploads\\product_image-1684230404364.png',NULL,'not-available','1'),(10,'ข้าวไข่เจียว','หร่อย','\\uploads\\product_image-1684230452067.jpg','40','not-available','1'),(11,'กบ','AHHHHHHHHHHHHH','\\uploads\\product_image-1684231326838.jpg','1000000000000','not-available','3'),(12,'Cat','meow meow...','\\uploads\\product_image-1684311762906.jpg','100000','not-available','8');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queues`
--

DROP TABLE IF EXISTS `queues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queues` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(45) DEFAULT NULL,
  `user_id` varchar(45) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queues`
--

LOCK TABLES `queues` WRITE;
/*!40000 ALTER TABLE `queues` DISABLE KEYS */;
/*!40000 ALTER TABLE `queues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shops`
--

DROP TABLE IF EXISTS `shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shops` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `picture` varchar(200) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  `create_by_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shops`
--

LOCK TABLES `shops` WRITE;
/*!40000 ALTER TABLE `shops` DISABLE KEYS */;
INSERT INTO `shops` VALUES (1,'ร้านก๋วยเตี๋ยว','\\uploads\\myImage-1682342110030.jpg','',NULL),(2,'ร้าน1','\\uploads\\shop_image-1683913503139.png','ร้านค้า',NULL),(3,'ร้าน2','\\uploads\\shop_image-1683960077116.jpg','Bla Bla......',NULL),(4,'ร้าน3','\\uploads\\shop_image-1683960329478.jpg','Ahhhhhhhhhhhhhhhhhhhh',NULL),(5,'aummmmmmmmmmmmmmmmm','\\uploads\\shop_image-1683960558922.png','ddddddddddddddddddd',NULL),(6,'Shhhhh','\\uploads\\shop_image-1683960712766.webp','ddd',NULL),(7,'Test','\\uploads\\shop_image-1684221747607.jpg','BLA BLA BLA....',NULL),(8,'Test','\\uploads\\shop_image-1684221747873.jpg','BLA BLA BLA....',NULL),(9,'Aum','\\uploads\\shop_image-1684221774613.jpg','AUM AUM AUM.................',NULL),(10,'dada','\\uploads\\shop_image-1684228861949.webp','dddd',NULL),(11,'aa','\\uploads\\shop_image-1684316367720.png','aa',NULL),(12,'aa','\\uploads\\shop_image-1684316449894.png','aa','1'),(13,'aa','\\uploads\\shop_image-1684316462243.png','aa','1'),(14,'aa','\\uploads\\shop_image-1684316471302.png','aa','1'),(15,'aa','\\uploads\\shop_image-1684316476390.png','aa','1'),(16,'Test','\\uploads\\shop_image-1684393610081.jpg','...','1');
/*!40000 ALTER TABLE `shops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `token` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_UNIQUE` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES (1,1,'*a5FUzgt-KjQI#*RujRi$U-$zce3=lfldvG5JbUosn^lw6ZoPd5SNG8fG$3bDJ9tX6t^RRBSe9qZMBnI!6r/L8*WOs!sJAFx!DUY');
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `role` varchar(45) DEFAULT 'customer',
  `email` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Boblnw','$2b$05$tlByTcslBrr812jaqVMBnuLzbLBmRNSMjJdT1ENbqckwdj2sEn8ZW','Bob','Bob','0960542824','customer','Boblnw2545@gmail.com'),(2,'Aumlnw1234','$2b$05$4fO2RfHAw84jqOU77lXDEeScwhDmuZT18nhvcacOSkdnZPQWtPEw6','Puttpong','Puttpong','0960542824','customer','Aum1234@gmail.com'),(3,'Admin','$2b$05$VyA2uVfmTMBKTXQljVSpDeHR1Nre25CNapliz2yw./SWI0d.CsTdS','Admin','Admin','0123456789','customer','Admin@gmail.com'),(4,'Admin1','$2b$05$wB8fYJ/xx/rWf6f99vDWzONeGYyJbg/BJIbyX6yGdK/6NmDGeV.96','Admin','Admin','0123456789','customer','Admin@gmail.com');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-18 17:57:45
